/****************************************************************************
** Meta object code from reading C++ file 'qwt_designer_plugin.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../qwt_designer_plugin.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/qplugin.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qwt_designer_plugin.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetInterface_t {
    QByteArrayData data[1];
    char stringdata[42];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetInterface_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetInterface_t qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetInterface = {
    {
QT_MOC_LITERAL(0, 0, 40)
    },
    "QwtDesignerPlugin::CustomWidgetInterface\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__CustomWidgetInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::CustomWidgetInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::CustomWidgetInterface::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetInterface.data,
      qt_meta_data_QwtDesignerPlugin__CustomWidgetInterface,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::CustomWidgetInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::CustomWidgetInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetInterface.stringdata))
        return static_cast<void*>(const_cast< CustomWidgetInterface*>(this));
    if (!strcmp(_clname, "QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< CustomWidgetInterface*>(this));
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< CustomWidgetInterface*>(this));
    return QObject::qt_metacast(_clname);
}

int QwtDesignerPlugin::CustomWidgetInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetCollectionInterface_t {
    QByteArrayData data[1];
    char stringdata[52];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetCollectionInterface_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetCollectionInterface_t qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetCollectionInterface = {
    {
QT_MOC_LITERAL(0, 0, 50)
    },
    "QwtDesignerPlugin::CustomWidgetCollectionInterface\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__CustomWidgetCollectionInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::CustomWidgetCollectionInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::CustomWidgetCollectionInterface::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetCollectionInterface.data,
      qt_meta_data_QwtDesignerPlugin__CustomWidgetCollectionInterface,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::CustomWidgetCollectionInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::CustomWidgetCollectionInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetCollectionInterface.stringdata))
        return static_cast<void*>(const_cast< CustomWidgetCollectionInterface*>(this));
    if (!strcmp(_clname, "QDesignerCustomWidgetCollectionInterface"))
        return static_cast< QDesignerCustomWidgetCollectionInterface*>(const_cast< CustomWidgetCollectionInterface*>(this));
    if (!strcmp(_clname, "org.qt-project.Qt.QDesignerCustomWidgetCollectionInterface"))
        return static_cast< QDesignerCustomWidgetCollectionInterface*>(const_cast< CustomWidgetCollectionInterface*>(this));
    return QObject::qt_metacast(_clname);
}

int QwtDesignerPlugin::CustomWidgetCollectionInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}

QT_PLUGIN_METADATA_SECTION const uint qt_section_alignment_dummy = 42;

#ifdef QT_NO_DEBUG

QT_PLUGIN_METADATA_SECTION
static const unsigned char qt_pluginMetaData[] = {
    'Q', 'T', 'M', 'E', 'T', 'A', 'D', 'A', 'T', 'A', ' ', ' ',
    0x71, 0x62, 0x6a, 0x73, 0x01, 0x00, 0x00, 0x00,
    0xd4, 0x00, 0x00, 0x00, 0x0b, 0x00, 0x00, 0x00,
    0xc0, 0x00, 0x00, 0x00, 0x1b, 0x03, 0x00, 0x00,
    0x03, 0x00, 0x49, 0x49, 0x44, 0x00, 0x00, 0x00,
    0x3a, 0x00, 0x6f, 0x72, 0x67, 0x2e, 0x71, 0x74,
    0x2d, 0x70, 0x72, 0x6f, 0x6a, 0x65, 0x63, 0x74,
    0x2e, 0x51, 0x74, 0x2e, 0x51, 0x44, 0x65, 0x73,
    0x69, 0x67, 0x6e, 0x65, 0x72, 0x43, 0x75, 0x73,
    0x74, 0x6f, 0x6d, 0x57, 0x69, 0x64, 0x67, 0x65,
    0x74, 0x43, 0x6f, 0x6c, 0x6c, 0x65, 0x63, 0x74,
    0x69, 0x6f, 0x6e, 0x49, 0x6e, 0x74, 0x65, 0x72,
    0x66, 0x61, 0x63, 0x65, 0x9b, 0x0c, 0x00, 0x00,
    0x09, 0x00, 0x63, 0x6c, 0x61, 0x73, 0x73, 0x4e,
    0x61, 0x6d, 0x65, 0x00, 0x1f, 0x00, 0x43, 0x75,
    0x73, 0x74, 0x6f, 0x6d, 0x57, 0x69, 0x64, 0x67,
    0x65, 0x74, 0x43, 0x6f, 0x6c, 0x6c, 0x65, 0x63,
    0x74, 0x69, 0x6f, 0x6e, 0x49, 0x6e, 0x74, 0x65,
    0x72, 0x66, 0x61, 0x63, 0x65, 0x00, 0x00, 0x00,
    0x3a, 0x40, 0xa0, 0x00, 0x07, 0x00, 0x76, 0x65,
    0x72, 0x73, 0x69, 0x6f, 0x6e, 0x00, 0x00, 0x00,
    0x11, 0x00, 0x00, 0x00, 0x05, 0x00, 0x64, 0x65,
    0x62, 0x75, 0x67, 0x00, 0x95, 0x16, 0x00, 0x00,
    0x08, 0x00, 0x4d, 0x65, 0x74, 0x61, 0x44, 0x61,
    0x74, 0x61, 0x00, 0x00, 0x0c, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x0c, 0x00, 0x00, 0x00, 0xa4, 0x00, 0x00, 0x00,
    0x54, 0x00, 0x00, 0x00, 0x98, 0x00, 0x00, 0x00,
    0x88, 0x00, 0x00, 0x00
};

#else // QT_NO_DEBUG

QT_PLUGIN_METADATA_SECTION
static const unsigned char qt_pluginMetaData[] = {
    'Q', 'T', 'M', 'E', 'T', 'A', 'D', 'A', 'T', 'A', ' ', ' ',
    0x71, 0x62, 0x6a, 0x73, 0x01, 0x00, 0x00, 0x00,
    0xd4, 0x00, 0x00, 0x00, 0x0b, 0x00, 0x00, 0x00,
    0xc0, 0x00, 0x00, 0x00, 0x1b, 0x03, 0x00, 0x00,
    0x03, 0x00, 0x49, 0x49, 0x44, 0x00, 0x00, 0x00,
    0x3a, 0x00, 0x6f, 0x72, 0x67, 0x2e, 0x71, 0x74,
    0x2d, 0x70, 0x72, 0x6f, 0x6a, 0x65, 0x63, 0x74,
    0x2e, 0x51, 0x74, 0x2e, 0x51, 0x44, 0x65, 0x73,
    0x69, 0x67, 0x6e, 0x65, 0x72, 0x43, 0x75, 0x73,
    0x74, 0x6f, 0x6d, 0x57, 0x69, 0x64, 0x67, 0x65,
    0x74, 0x43, 0x6f, 0x6c, 0x6c, 0x65, 0x63, 0x74,
    0x69, 0x6f, 0x6e, 0x49, 0x6e, 0x74, 0x65, 0x72,
    0x66, 0x61, 0x63, 0x65, 0x95, 0x0c, 0x00, 0x00,
    0x08, 0x00, 0x4d, 0x65, 0x74, 0x61, 0x44, 0x61,
    0x74, 0x61, 0x00, 0x00, 0x0c, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x1b, 0x10, 0x00, 0x00, 0x09, 0x00, 0x63, 0x6c,
    0x61, 0x73, 0x73, 0x4e, 0x61, 0x6d, 0x65, 0x00,
    0x1f, 0x00, 0x43, 0x75, 0x73, 0x74, 0x6f, 0x6d,
    0x57, 0x69, 0x64, 0x67, 0x65, 0x74, 0x43, 0x6f,
    0x6c, 0x6c, 0x65, 0x63, 0x74, 0x69, 0x6f, 0x6e,
    0x49, 0x6e, 0x74, 0x65, 0x72, 0x66, 0x61, 0x63,
    0x65, 0x00, 0x00, 0x00, 0x31, 0x00, 0x00, 0x00,
    0x05, 0x00, 0x64, 0x65, 0x62, 0x75, 0x67, 0x00,
    0x3a, 0x40, 0xa0, 0x00, 0x07, 0x00, 0x76, 0x65,
    0x72, 0x73, 0x69, 0x6f, 0x6e, 0x00, 0x00, 0x00,
    0x0c, 0x00, 0x00, 0x00, 0x54, 0x00, 0x00, 0x00,
    0x70, 0x00, 0x00, 0x00, 0xa4, 0x00, 0x00, 0x00,
    0xb0, 0x00, 0x00, 0x00
};
#endif // QT_NO_DEBUG

using namespace QwtDesignerPlugin;
QT_MOC_EXPORT_PLUGIN(QwtDesignerPlugin::CustomWidgetCollectionInterface, CustomWidgetCollectionInterface)

struct qt_meta_stringdata_QwtDesignerPlugin__PlotInterface_t {
    QByteArrayData data[1];
    char stringdata[34];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__PlotInterface_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__PlotInterface_t qt_meta_stringdata_QwtDesignerPlugin__PlotInterface = {
    {
QT_MOC_LITERAL(0, 0, 32)
    },
    "QwtDesignerPlugin::PlotInterface\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__PlotInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::PlotInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::PlotInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__PlotInterface.data,
      qt_meta_data_QwtDesignerPlugin__PlotInterface,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::PlotInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::PlotInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__PlotInterface.stringdata))
        return static_cast<void*>(const_cast< PlotInterface*>(this));
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< PlotInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::PlotInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__PlotCanvasInterface_t {
    QByteArrayData data[1];
    char stringdata[40];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__PlotCanvasInterface_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__PlotCanvasInterface_t qt_meta_stringdata_QwtDesignerPlugin__PlotCanvasInterface = {
    {
QT_MOC_LITERAL(0, 0, 38)
    },
    "QwtDesignerPlugin::PlotCanvasInterface\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__PlotCanvasInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::PlotCanvasInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::PlotCanvasInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__PlotCanvasInterface.data,
      qt_meta_data_QwtDesignerPlugin__PlotCanvasInterface,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::PlotCanvasInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::PlotCanvasInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__PlotCanvasInterface.stringdata))
        return static_cast<void*>(const_cast< PlotCanvasInterface*>(this));
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< PlotCanvasInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::PlotCanvasInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__AnalogClockInterface_t {
    QByteArrayData data[1];
    char stringdata[41];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__AnalogClockInterface_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__AnalogClockInterface_t qt_meta_stringdata_QwtDesignerPlugin__AnalogClockInterface = {
    {
QT_MOC_LITERAL(0, 0, 39)
    },
    "QwtDesignerPlugin::AnalogClockInterface\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__AnalogClockInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::AnalogClockInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::AnalogClockInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__AnalogClockInterface.data,
      qt_meta_data_QwtDesignerPlugin__AnalogClockInterface,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::AnalogClockInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::AnalogClockInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__AnalogClockInterface.stringdata))
        return static_cast<void*>(const_cast< AnalogClockInterface*>(this));
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< AnalogClockInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::AnalogClockInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__CompassInterface_t {
    QByteArrayData data[1];
    char stringdata[37];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__CompassInterface_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__CompassInterface_t qt_meta_stringdata_QwtDesignerPlugin__CompassInterface = {
    {
QT_MOC_LITERAL(0, 0, 35)
    },
    "QwtDesignerPlugin::CompassInterface\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__CompassInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::CompassInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::CompassInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__CompassInterface.data,
      qt_meta_data_QwtDesignerPlugin__CompassInterface,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::CompassInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::CompassInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__CompassInterface.stringdata))
        return static_cast<void*>(const_cast< CompassInterface*>(this));
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< CompassInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::CompassInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__CounterInterface_t {
    QByteArrayData data[1];
    char stringdata[37];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__CounterInterface_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__CounterInterface_t qt_meta_stringdata_QwtDesignerPlugin__CounterInterface = {
    {
QT_MOC_LITERAL(0, 0, 35)
    },
    "QwtDesignerPlugin::CounterInterface\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__CounterInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::CounterInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::CounterInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__CounterInterface.data,
      qt_meta_data_QwtDesignerPlugin__CounterInterface,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::CounterInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::CounterInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__CounterInterface.stringdata))
        return static_cast<void*>(const_cast< CounterInterface*>(this));
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< CounterInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::CounterInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__DialInterface_t {
    QByteArrayData data[1];
    char stringdata[34];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__DialInterface_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__DialInterface_t qt_meta_stringdata_QwtDesignerPlugin__DialInterface = {
    {
QT_MOC_LITERAL(0, 0, 32)
    },
    "QwtDesignerPlugin::DialInterface\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__DialInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::DialInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::DialInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__DialInterface.data,
      qt_meta_data_QwtDesignerPlugin__DialInterface,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::DialInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::DialInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__DialInterface.stringdata))
        return static_cast<void*>(const_cast< DialInterface*>(this));
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< DialInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::DialInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__KnobInterface_t {
    QByteArrayData data[1];
    char stringdata[34];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__KnobInterface_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__KnobInterface_t qt_meta_stringdata_QwtDesignerPlugin__KnobInterface = {
    {
QT_MOC_LITERAL(0, 0, 32)
    },
    "QwtDesignerPlugin::KnobInterface\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__KnobInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::KnobInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::KnobInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__KnobInterface.data,
      qt_meta_data_QwtDesignerPlugin__KnobInterface,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::KnobInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::KnobInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__KnobInterface.stringdata))
        return static_cast<void*>(const_cast< KnobInterface*>(this));
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< KnobInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::KnobInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__ScaleWidgetInterface_t {
    QByteArrayData data[1];
    char stringdata[41];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__ScaleWidgetInterface_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__ScaleWidgetInterface_t qt_meta_stringdata_QwtDesignerPlugin__ScaleWidgetInterface = {
    {
QT_MOC_LITERAL(0, 0, 39)
    },
    "QwtDesignerPlugin::ScaleWidgetInterface\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__ScaleWidgetInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::ScaleWidgetInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::ScaleWidgetInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__ScaleWidgetInterface.data,
      qt_meta_data_QwtDesignerPlugin__ScaleWidgetInterface,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::ScaleWidgetInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::ScaleWidgetInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__ScaleWidgetInterface.stringdata))
        return static_cast<void*>(const_cast< ScaleWidgetInterface*>(this));
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< ScaleWidgetInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::ScaleWidgetInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__SliderInterface_t {
    QByteArrayData data[1];
    char stringdata[36];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__SliderInterface_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__SliderInterface_t qt_meta_stringdata_QwtDesignerPlugin__SliderInterface = {
    {
QT_MOC_LITERAL(0, 0, 34)
    },
    "QwtDesignerPlugin::SliderInterface\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__SliderInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::SliderInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::SliderInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__SliderInterface.data,
      qt_meta_data_QwtDesignerPlugin__SliderInterface,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::SliderInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::SliderInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__SliderInterface.stringdata))
        return static_cast<void*>(const_cast< SliderInterface*>(this));
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< SliderInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::SliderInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__TextLabelInterface_t {
    QByteArrayData data[1];
    char stringdata[39];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__TextLabelInterface_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__TextLabelInterface_t qt_meta_stringdata_QwtDesignerPlugin__TextLabelInterface = {
    {
QT_MOC_LITERAL(0, 0, 37)
    },
    "QwtDesignerPlugin::TextLabelInterface\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__TextLabelInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::TextLabelInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::TextLabelInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__TextLabelInterface.data,
      qt_meta_data_QwtDesignerPlugin__TextLabelInterface,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::TextLabelInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::TextLabelInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__TextLabelInterface.stringdata))
        return static_cast<void*>(const_cast< TextLabelInterface*>(this));
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< TextLabelInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::TextLabelInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__ThermoInterface_t {
    QByteArrayData data[1];
    char stringdata[36];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__ThermoInterface_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__ThermoInterface_t qt_meta_stringdata_QwtDesignerPlugin__ThermoInterface = {
    {
QT_MOC_LITERAL(0, 0, 34)
    },
    "QwtDesignerPlugin::ThermoInterface\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__ThermoInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::ThermoInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::ThermoInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__ThermoInterface.data,
      qt_meta_data_QwtDesignerPlugin__ThermoInterface,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::ThermoInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::ThermoInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__ThermoInterface.stringdata))
        return static_cast<void*>(const_cast< ThermoInterface*>(this));
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< ThermoInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::ThermoInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__WheelInterface_t {
    QByteArrayData data[1];
    char stringdata[35];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__WheelInterface_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__WheelInterface_t qt_meta_stringdata_QwtDesignerPlugin__WheelInterface = {
    {
QT_MOC_LITERAL(0, 0, 33)
    },
    "QwtDesignerPlugin::WheelInterface\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__WheelInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::WheelInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::WheelInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__WheelInterface.data,
      qt_meta_data_QwtDesignerPlugin__WheelInterface,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::WheelInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::WheelInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__WheelInterface.stringdata))
        return static_cast<void*>(const_cast< WheelInterface*>(this));
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< WheelInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::WheelInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__TaskMenuFactory_t {
    QByteArrayData data[1];
    char stringdata[36];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__TaskMenuFactory_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__TaskMenuFactory_t qt_meta_stringdata_QwtDesignerPlugin__TaskMenuFactory = {
    {
QT_MOC_LITERAL(0, 0, 34)
    },
    "QwtDesignerPlugin::TaskMenuFactory\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__TaskMenuFactory[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::TaskMenuFactory::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::TaskMenuFactory::staticMetaObject = {
    { &QExtensionFactory::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__TaskMenuFactory.data,
      qt_meta_data_QwtDesignerPlugin__TaskMenuFactory,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::TaskMenuFactory::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::TaskMenuFactory::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__TaskMenuFactory.stringdata))
        return static_cast<void*>(const_cast< TaskMenuFactory*>(this));
    return QExtensionFactory::qt_metacast(_clname);
}

int QwtDesignerPlugin::TaskMenuFactory::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QExtensionFactory::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__TaskMenuExtension_t {
    QByteArrayData data[4];
    char stringdata[70];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_QwtDesignerPlugin__TaskMenuExtension_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__TaskMenuExtension_t qt_meta_stringdata_QwtDesignerPlugin__TaskMenuExtension = {
    {
QT_MOC_LITERAL(0, 0, 36),
QT_MOC_LITERAL(1, 37, 14),
QT_MOC_LITERAL(2, 52, 0),
QT_MOC_LITERAL(3, 53, 15)
    },
    "QwtDesignerPlugin::TaskMenuExtension\0"
    "editProperties\0\0applyProperties\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__TaskMenuExtension[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   24,    2, 0x08,
       3,    1,   25,    2, 0x08,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,

       0        // eod
};

void QwtDesignerPlugin::TaskMenuExtension::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        TaskMenuExtension *_t = static_cast<TaskMenuExtension *>(_o);
        switch (_id) {
        case 0: _t->editProperties(); break;
        case 1: _t->applyProperties((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject QwtDesignerPlugin::TaskMenuExtension::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__TaskMenuExtension.data,
      qt_meta_data_QwtDesignerPlugin__TaskMenuExtension,  qt_static_metacall, 0, 0}
};


const QMetaObject *QwtDesignerPlugin::TaskMenuExtension::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::TaskMenuExtension::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__TaskMenuExtension.stringdata))
        return static_cast<void*>(const_cast< TaskMenuExtension*>(this));
    if (!strcmp(_clname, "QDesignerTaskMenuExtension"))
        return static_cast< QDesignerTaskMenuExtension*>(const_cast< TaskMenuExtension*>(this));
    if (!strcmp(_clname, "org.qt-project.Qt.Designer.TaskMenu"))
        return static_cast< QDesignerTaskMenuExtension*>(const_cast< TaskMenuExtension*>(this));
    return QObject::qt_metacast(_clname);
}

int QwtDesignerPlugin::TaskMenuExtension::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
