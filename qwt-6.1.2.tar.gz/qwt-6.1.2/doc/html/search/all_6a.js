var searchData=
[
  ['juliandayforepoch',['JulianDayForEpoch',['../class_qwt_date.html#af636fffdebea2e4463fc32461b1217e0aed8ee8f3dbc5b7a5e953b3ec51a79108',1,'QwtDate']]]
];
